# Curso #

    - Módulo 1 - HTML/CSS (210h)
        - Unidad 1 - HTML  (80h)
        - Unidad 2 - CSS (70h)
        - Unidad 3 - Formularios y Plantillas (60h)
    - Módulo 2 - JS (180h)
        - Unidad 1 - JS (90h)
        - Unidad 2 - Formularios (validacion) y pruebas (90h)
    - Módulo 3 - Publicacion (90h)