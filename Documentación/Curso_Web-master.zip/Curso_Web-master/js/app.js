/* Ejemplo de comentario en bloque */
// Ejemplo de comentario en linea
console.log('Hola desde un fichero')